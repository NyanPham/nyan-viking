(function ($) {
	var halo = {
	    initInstagramSlider: function() {
	        var instagramBlock = $('[data-instagram-feed]');

	        instagramBlock.each(function() {
	            var self = $(this),
	                dataRows = self.data('rows'),
	                dataSlideRow = self.data('slide-rows'),
	                dataArrow = self.data('arrow'),
	                dataMode = self.data('mode'),
	                dataLimit = self.data('limit');
	                
	            if (dataSlideRow == 2) {
            		var x =  self.children();
		            for (i = 0; i < x.length ; i += 2) {
		              x.slice(i,i+2).wrapAll('<div class="'+ i +'"></div>');
		            }
	            }

	            self.slick({
	              	infinite: false,
	              	speed: 1000, 
	              	centerMode: dataMode,
					get centerPadding() {
					    if (dataMode == true) {
					        return this.centerPadding = '11.36%';
					    }
					},
	              	arrows: dataArrow,
	              	nextArrow: window.arrows.icon_next,
                    prevArrow: window.arrows.icon_prev,
	              	slidesToShow: dataRows,
	              	slidesToScroll: dataRows,
	              	responsive: [
	                {
	                  	breakpoint: 1200,
	                  	settings: {
							get slidesPerRow() {
							    if (dataSlideRow == 2) {
									this.slidesPerRow = 1,
									this.rows = 2
							    }
							},
							get slidesToScroll() {
							    if (dataSlideRow == 1) {
									return this.slidesToScroll = 4
							    }
							},
							slidesToShow: 4
	                  	}
	                },
	                {
	                  	breakpoint: 992,
	                  	settings: {
							get slidesPerRow() {
							    if (dataSlideRow == 2) {
									this.slidesPerRow = 1,
									this.rows = 2
							    }
							},
							get slidesToScroll() {
							    if (dataSlideRow == 1) {
									return this.slidesToScroll = 3
							    }
							},
							slidesToShow: 3
		                }
	                },
	                {
	                  	breakpoint: 768,
	                  	settings: {
		                  	get slidesPerRow() {
							    if (dataSlideRow == 2) {
									this.slidesPerRow = 1,
									this.rows = 2
							    }
							},
							get slidesToScroll() {
							    if (dataSlideRow == 1) {
									return this.slidesToScroll = 1
							    }
							},
							slidesToShow: 2
	                  	}
	                }                                          
	              ]
	            });
	        });
	    }
	}
	halo.initInstagramSlider();
})(jQuery);