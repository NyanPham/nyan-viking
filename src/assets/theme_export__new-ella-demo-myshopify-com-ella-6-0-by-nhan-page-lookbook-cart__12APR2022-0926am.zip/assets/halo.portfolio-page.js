function initShuffle(){
	// init shuffle
	var Shuffle = window.Shuffle;
	var element = document.querySelector('.shuffle-container');
	var sizer = document.querySelector('.sizer-element');

	var shuffleInstance = new Shuffle(element, {
		itemSelector: '.pfl-item',
		sizer: sizer
	});
	$('.filter-list li a').off('click').on('click', function(e){
		e.preventDefault();
		console.log(e.target)
		$('.filter-list li').removeClass('active');
		var thisLi = $(this).parent('li').addClass('active');
		var filterVal = e.target.getAttribute('data-filter');
		if(filterVal == 'all'){
			shuffleInstance.filter();
		}else{
			shuffleInstance.filter(function (element) {
				if($(element).data('groups') != undefined)
					return $(element).data('groups').indexOf(filterVal) != -1;
			});
		}
		setTimeout(function(){
			$('.pfl-wrapper').removeClass('open-sidebar');
		},300)

	})
	
	// init fancybox api
	$('.pfl-item i').off('click').on('click',function(){
		$(this).parents('.pfl-item').find('.pfl-thumb').trigger('click')
	})
	$('.pfl-thumb').off('click').on('click',function(){
		if($(this).data('gallery')) {
			var imageArr = $(this).data('gallery').split(',');
			var fancyObj = imageArr.map(function(image,index){
				return ({
					src  : image,
					opts : {
						caption : (index + 1) +' of '+ imageArr.length
					}
				})
			});
			$.fancybox.open(fancyObj,{
				loop : true,
				thumbs : {
					autoStart : false
				},
				slideClass: "portfolio",
				buttons: [
				],
				clickSlide: "close",
				mobile: {
					clickSlide: function(current, event) {
						return "close";
					}
				},
				afterLoad: function(instance, slide){
					// move caption into image box
					instance.$caption.appendTo('.fancybox-image-wrap').text(instance.$caption.text());
					// create close icon
					$('.fancybox-image-wrap').append('<div class="close-box"></div>')
					//close fancybox
					$('.close-box').on('click touchend' ,function(){
						instance.close();
					})
				}
			});
		}
	})

	//toggle sidebar
	$('.pfl-filter-icon').off('click').on('click',function(){
		$('.pfl-wrapper').toggleClass('open-sidebar');
	})

}
$(document).ready(function(){
	initShuffle();
})
$(document)
.on('shopify:section:load', initShuffle)
.on('shopify:section:unload', initShuffle)
